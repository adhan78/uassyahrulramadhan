
# SyahrulFood - UAS PBK
Aplikasi pemesanan makanan menggunakan Vue.js, Vue Router, Pinia, dan json-server.
