
<template>
  <div>
    <h1>SyahrulFood - Aplikasi Pemesanan Makanan</h1>
    <router-view />
  </div>
</template>
